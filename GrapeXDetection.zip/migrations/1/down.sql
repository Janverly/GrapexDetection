
DROP INDEX idx_scans_created_at;
DROP INDEX idx_scans_user_id;
DROP TABLE diseases;
DROP TABLE scans;
