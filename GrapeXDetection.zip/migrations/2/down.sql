
DELETE FROM diseases WHERE name IN ('Black Rot', 'Downy Mildew', 'Powdery Mildew', 'Leaf Spot');
