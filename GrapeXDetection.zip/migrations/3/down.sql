
DELETE FROM scans WHERE user_id = 'admin@grapexdetection.com';
