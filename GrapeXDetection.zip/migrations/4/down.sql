
DROP INDEX idx_reports_type;
DROP INDEX idx_reports_severity;
DROP INDEX idx_reports_status;
DROP INDEX idx_reports_user_id;
DROP TABLE reports;
