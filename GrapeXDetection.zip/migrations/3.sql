
INSERT INTO scans (user_id, image_url, disease_detected, confidence_score, recommendations, location_lat, location_lng, created_at, updated_at)
VALUES ('admin@grapexdetection.com', 'https://images.unsplash.com/photo-1596367407372-96cb88503db6?w=400', 'Healthy', 0.95, 'Continue monitoring. Plant looks healthy with good leaf structure.', 40.7128, -74.0060, datetime('now'), datetime('now'));
